#ifndef __RESOURCE_bloatpad_H__
#define __RESOURCE_bloatpad_H__

#include <gio/gio.h>

extern GResource *bloatpad_get_resource (void);
#endif
